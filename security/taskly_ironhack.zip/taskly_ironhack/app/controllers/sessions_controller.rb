class SessionsController < ApplicationController
	def create
		user=User.find(email: params[:session][:email].downcase)

		if user && user.authenticate(params[:session][:enail].downcase)
			session[:user_id] = user.id
			redirect_to user
		else
			redirect_to '/login'
		end
	end

	def destroy
		session.clear
		redirect_to '/login'
	end
end
