require 'rails_helper'

RSpec.describe Admin::TasksController, type: :controller do

end
